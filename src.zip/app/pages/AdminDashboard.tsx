import { useState } from "react";
import { AppLayout } from "../components/layout/AppLayout";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import {
  Shield,
  Users,
  Clock,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Database,
  Activity,
  BarChart3,
  Download,
  Calendar,
  DollarSign,
} from "lucide-react";

export function AdminDashboard() {
  const [selectedPeriod, setSelectedPeriod] = useState("7d");

  // Mock data - Métricas principais
  const stats = {
    totalUsers: 1247,
    activeUsers: 892,
    totalClasses: 3456,
    totalCredits: 15678,
    creditTransactions: 4523,
    avgSatisfaction: 4.7,
    reportsPending: 3,
    systemUptime: 99.9,
  };

  // Transações recentes de créditos
  const recentTransactions = [
    {
      id: 1,
      from: "Maria Silva",
      to: "Sistema",
      amount: 2,
      type: "earned",
      date: "2026-03-20 14:30",
      class: "Python Avançado",
    },
    {
      id: 2,
      from: "João Santos",
      to: "Ana Costa",
      amount: 1,
      type: "spent",
      date: "2026-03-20 13:15",
      class: "Inglês Conversação",
    },
    {
      id: 3,
      from: "Pedro Oliveira",
      to: "Sistema",
      amount: 3,
      type: "earned",
      date: "2026-03-20 11:00",
      class: "Marketing Digital",
    },
  ];

  // Usuários mais ativos
  const topUsers = [
    { name: "Maria Silva", classesTeaching: 45, classesLearning: 23, credits: 22 },
    { name: "João Santos", classesTeaching: 38, classesLearning: 31, credits: 7 },
    { name: "Ana Costa", classesTeaching: 52, classesLearning: 15, credits: 37 },
  ];

  // Denúncias pendentes
  const pendingReports = [
    {
      id: "REP-001",
      reporter: "Usuário#1234",
      reported: "João Silva",
      type: "Falta sem aviso",
      date: "2026-03-20",
      priority: "high",
    },
    {
      id: "REP-002",
      reporter: "Usuário#5678",
      reported: "Maria Santos",
      type: "Comportamento inadequado",
      date: "2026-03-19",
      priority: "medium",
    },
    {
      id: "REP-003",
      reporter: "Usuário#9012",
      reported: "Pedro Costa",
      type: "Conteúdo inapropriado",
      date: "2026-03-18",
      priority: "low",
    },
  ];

  const getPriorityBadge = (priority: string) => {
    const variants = {
      high: { variant: "destructive" as const, label: "Alta" },
      medium: { variant: "secondary" as const, label: "Média" },
      low: { variant: "outline" as const, label: "Baixa" },
    };
    return variants[priority as keyof typeof variants];
  };

  return (
    <AppLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl mb-2 flex items-center gap-3">
              <Shield className="size-10 text-blue-600" />
              Painel Administrativo
            </h1>
            <p className="text-gray-600">
              Gestão completa da plataforma LifeTime
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger className="w-40">
                <Calendar className="mr-2 size-4" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="24h">Últimas 24h</SelectItem>
                <SelectItem value="7d">Últimos 7 dias</SelectItem>
                <SelectItem value="30d">Últimos 30 dias</SelectItem>
                <SelectItem value="90d">Últimos 90 dias</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Download className="mr-2 size-4" />
              Exportar Relatório
            </Button>
          </div>
        </div>

        {/* KPIs Principais */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Usuários Totais</p>
              <Users className="size-5 text-blue-600" />
            </div>
            <p className="text-3xl mb-1">{stats.totalUsers.toLocaleString()}</p>
            <p className="text-sm text-green-600">+12% vs mês anterior</p>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Usuários Ativos</p>
              <Activity className="size-5 text-green-600" />
            </div>
            <p className="text-3xl mb-1">{stats.activeUsers.toLocaleString()}</p>
            <p className="text-sm text-gray-600">
              {((stats.activeUsers / stats.totalUsers) * 100).toFixed(1)}% do total
            </p>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Total de Aulas</p>
              <BarChart3 className="size-5 text-purple-600" />
            </div>
            <p className="text-3xl mb-1">{stats.totalClasses.toLocaleString()}</p>
            <p className="text-sm text-green-600">+24% vs mês anterior</p>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Créditos Circulando</p>
              <Clock className="size-5 text-orange-600" />
            </div>
            <p className="text-3xl mb-1">{stats.totalCredits.toLocaleString()}</p>
            <p className="text-sm text-gray-600">
              {stats.creditTransactions.toLocaleString()} transações
            </p>
          </Card>
        </div>

        {/* Sistema e Alertas */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium">Uptime do Sistema</h3>
              <CheckCircle className="size-5 text-green-600" />
            </div>
            <p className="text-4xl mb-2">{stats.systemUptime}%</p>
            <p className="text-sm text-gray-600">Últimos 30 dias</p>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium">Satisfação Média</h3>
              <TrendingUp className="size-5 text-blue-600" />
            </div>
            <p className="text-4xl mb-2">{stats.avgSatisfaction}/5.0</p>
            <div className="flex gap-1">
              {[...Array(5)].map((_, i) => (
                <div
                  key={i}
                  className={`h-2 flex-1 rounded ${
                    i < Math.floor(stats.avgSatisfaction)
                      ? "bg-yellow-400"
                      : "bg-gray-200"
                  }`}
                />
              ))}
            </div>
          </Card>

          <Card className="p-6 bg-red-50 border-red-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium">Denúncias Pendentes</h3>
              <AlertTriangle className="size-5 text-red-600" />
            </div>
            <p className="text-4xl mb-2">{stats.reportsPending}</p>
            <Button size="sm" variant="destructive" className="w-full">
              Revisar Agora
            </Button>
          </Card>
        </div>

        <Tabs defaultValue="transactions">
          <TabsList>
            <TabsTrigger value="transactions">
              <DollarSign className="mr-2 size-4" />
              Transações de Créditos
            </TabsTrigger>
            <TabsTrigger value="users">
              <Users className="mr-2 size-4" />
              Usuários
            </TabsTrigger>
            <TabsTrigger value="reports">
              <AlertTriangle className="mr-2 size-4" />
              Denúncias
            </TabsTrigger>
            <TabsTrigger value="database">
              <Database className="mr-2 size-4" />
              Banco de Dados
            </TabsTrigger>
          </TabsList>

          <TabsContent value="transactions" className="mt-6">
            <Card className="p-6">
              <h3 className="text-xl mb-4">Transações Recentes de Créditos</h3>
              <p className="text-sm text-gray-600 mb-6">
                O <strong>Sistema</strong> atua como o "cérebro" que converte
                automaticamente horas ensinadas em créditos para os usuários.
              </p>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>De</TableHead>
                    <TableHead>Para</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Aula</TableHead>
                    <TableHead>Data/Hora</TableHead>
                    <TableHead className="text-right">Créditos</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentTransactions.map((tx) => (
                    <TableRow key={tx.id}>
                      <TableCell className="font-mono text-sm">
                        TX-{tx.id.toString().padStart(4, "0")}
                      </TableCell>
                      <TableCell>{tx.from}</TableCell>
                      <TableCell>
                        {tx.to === "Sistema" ? (
                          <Badge variant="secondary">Sistema</Badge>
                        ) : (
                          tx.to
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            tx.type === "earned" ? "default" : "outline"
                          }
                        >
                          {tx.type === "earned" ? "Ganho" : "Gasto"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">{tx.class}</TableCell>
                      <TableCell className="text-sm text-gray-600">
                        {tx.date}
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        <span
                          className={
                            tx.type === "earned"
                              ? "text-green-600"
                              : "text-orange-600"
                          }
                        >
                          {tx.type === "earned" ? "+" : "-"}
                          {tx.amount}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="mt-6">
            <Card className="p-6">
              <h3 className="text-xl mb-4">Usuários Mais Ativos</h3>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead className="text-right">
                      Aulas Ensinadas
                    </TableHead>
                    <TableHead className="text-right">
                      Aulas Aprendidas
                    </TableHead>
                    <TableHead className="text-right">
                      Saldo de Créditos
                    </TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {topUsers.map((user, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell className="text-right text-green-600">
                        {user.classesTeaching}
                      </TableCell>
                      <TableCell className="text-right text-blue-600">
                        {user.classesLearning}
                      </TableCell>
                      <TableCell className="text-right">
                        <Badge variant="secondary">{user.credits}</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button size="sm" variant="outline">
                          Ver Detalhes
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>

          <TabsContent value="reports" className="mt-6">
            <Card className="p-6">
              <h3 className="text-xl mb-4">Denúncias para Moderação</h3>
              <p className="text-sm text-gray-600 mb-6">
                Sistema de mediação de conflitos e verificação de violações das
                regras da comunidade.
              </p>
              <div className="space-y-4">
                {pendingReports.map((report) => {
                  const badge = getPriorityBadge(report.priority);
                  return (
                    <div
                      key={report.id}
                      className="p-4 border rounded-lg hover:bg-gray-50"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <span className="font-mono text-sm text-gray-500">
                              {report.id}
                            </span>
                            <Badge variant={badge.variant}>{badge.label}</Badge>
                            <Badge variant="outline">{report.type}</Badge>
                          </div>
                          <p className="text-sm">
                            <strong>Denunciado:</strong> {report.reported}
                          </p>
                          <p className="text-sm text-gray-600">
                            Por: {report.reporter} em {report.date}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">
                            Investigar
                          </Button>
                          <Button size="sm" variant="destructive">
                            Tomar Ação
                          </Button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="database" className="mt-6">
            <Card className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <Database className="size-8 text-blue-600" />
                <div>
                  <h3 className="text-xl">Banco de Dados</h3>
                  <p className="text-sm text-gray-600">
                    Sistema responsável pela segurança e histórico de todas as
                    transações
                  </p>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="p-6 bg-gray-50 rounded-lg">
                  <h4 className="mb-4">Informações do Sistema</h4>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total de Registros:</span>
                      <span className="font-medium">1,247,893</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Tamanho do BD:</span>
                      <span className="font-medium">2.4 GB</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Último Backup:</span>
                      <span className="font-medium">Hoje, 03:00</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Status:</span>
                      <Badge variant="default">Saudável</Badge>
                    </div>
                  </div>
                </div>

                <div className="p-6 bg-blue-50 rounded-lg">
                  <h4 className="mb-4">Segurança e Integridade</h4>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="size-5 text-green-600" />
                      <span className="text-sm">Criptografia Ativa (AES-256)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="size-5 text-green-600" />
                      <span className="text-sm">Backup Automático Diário</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="size-5 text-green-600" />
                      <span className="text-sm">
                        Auditoria de Transações Habilitada
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="size-5 text-green-600" />
                      <span className="text-sm">Conformidade LGPD</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex gap-3">
                <Button variant="outline">
                  <Download className="mr-2 size-4" />
                  Exportar Dados
                </Button>
                <Button variant="outline">Executar Backup Manual</Button>
                <Button variant="outline">Ver Logs de Auditoria</Button>
              </div>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Papéis do Sistema */}
        <div className="mt-8 grid md:grid-cols-3 gap-6">
          <Card className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <Users className="size-12 mb-4 text-blue-600" />
            <h3 className="text-xl mb-2">Usuário</h3>
            <p className="text-sm text-gray-700">
              Ensina e aprende na plataforma. Cada hora ensinando gera créditos
              automaticamente para usar em aprendizado.
            </p>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <Activity className="size-12 mb-4 text-purple-600" />
            <h3 className="text-xl mb-2">Sistema</h3>
            <p className="text-sm text-gray-700">
              Atua como o "cérebro" que converte automaticamente horas em
              créditos e gerencia todas as transações da economia do conhecimento.
            </p>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <Database className="size-12 mb-4 text-green-600" />
            <h3 className="text-xl mb-2">Banco de Dados</h3>
            <p className="text-sm text-gray-700">
              Garante a segurança, integridade e histórico completo de todas as
              transações, perfis e interações da plataforma.
            </p>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
