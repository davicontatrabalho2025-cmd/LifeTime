import { useState } from "react";
import { useNavigate } from "react-router";
import { AppLayout } from "../components/layout/AppLayout";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Avatar, AvatarFallback } from "../components/ui/avatar";
import { 
  Clock, 
  GraduationCap, 
  Users, 
  Calendar,
  BookOpen,
  TrendingUp,
  Bell,
  Settings,
  LogOut,
  Plus,
  Star
} from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export function Dashboard() {
  const navigate = useNavigate();
  const [credits, setCredits] = useState(5); // Créditos de boas-vindas

  const upcomingClasses = [
    { 
      id: 1, 
      title: "Introdução ao Python", 
      teacher: "Maria Silva", 
      date: "20 Mar 2026", 
      time: "14:00",
      type: "learning" as const
    },
    { 
      id: 2, 
      title: "Design Thinking Básico", 
      student: "João Santos", 
      date: "22 Mar 2026", 
      time: "10:00",
      type: "teaching" as const
    },
  ];

  const recentActivity = [
    { id: 1, text: "Você ganhou 5 créditos de boas-vindas", time: "Agora", icon: "🎉" },
    { id: 2, text: "Cadastro concluído com sucesso", time: "1 min atrás", icon: "✅" },
    { id: 3, text: "Perfil verificado", time: "2 min atrás", icon: "🔒" },
  ];

  return (
    <AppLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl mb-2">Bem-vindo(a) ao LifeTime! 🎉</h2>
          <p className="text-gray-600">
            Você ganhou 5 créditos de boas-vindas para começar sua jornada
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-gray-600">Créditos Disponíveis</p>
              <Clock className="size-5 text-blue-600" />
            </div>
            <p className="text-3xl">{credits}</p>
            <p className="text-sm text-gray-500 mt-1">horas de aprendizado</p>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-gray-600">Aulas Ensinadas</p>
              <GraduationCap className="size-5 text-green-600" />
            </div>
            <p className="text-3xl">0</p>
            <p className="text-sm text-gray-500 mt-1">comece a ensinar</p>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-gray-600">Aulas Aprendidas</p>
              <BookOpen className="size-5 text-purple-600" />
            </div>
            <p className="text-3xl">0</p>
            <p className="text-sm text-gray-500 mt-1">use seus créditos</p>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-gray-600">Conexões</p>
              <Users className="size-5 text-orange-600" />
            </div>
            <p className="text-3xl">0</p>
            <p className="text-sm text-gray-500 mt-1">construa sua rede</p>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Quick Actions */}
            <Card className="p-6">
              <h3 className="text-xl mb-4">Primeiros Passos</h3>
              <div className="grid sm:grid-cols-2 gap-4">
                <Button className="h-auto py-6 flex-col gap-2" variant="outline">
                  <Plus className="size-8" />
                  <span>Criar Aula</span>
                  <span className="text-xs text-gray-500">Ensine e ganhe créditos</span>
                </Button>
                <Button className="h-auto py-6 flex-col gap-2" variant="outline">
                  <BookOpen className="size-8" />
                  <span>Buscar Aulas</span>
                  <span className="text-xs text-gray-500">Use seus 5 créditos</span>
                </Button>
              </div>
            </Card>

            {/* Tabs */}
            <Card className="p-6">
              <Tabs defaultValue="upcoming">
                <TabsList className="mb-4">
                  <TabsTrigger value="upcoming">Próximas Aulas</TabsTrigger>
                  <TabsTrigger value="recommended">Recomendadas</TabsTrigger>
                </TabsList>

                <TabsContent value="upcoming" className="space-y-4">
                  {upcomingClasses.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <Calendar className="size-12 mx-auto mb-3 opacity-50" />
                      <p>Nenhuma aula agendada ainda</p>
                      <Button className="mt-4" variant="outline">
                        Explorar Aulas
                      </Button>
                    </div>
                  ) : (
                    upcomingClasses.map((cls) => (
                      <div key={cls.id} className="flex items-start gap-4 p-4 border rounded-lg hover:bg-gray-50">
                        <Avatar className="size-12">
                          <AvatarFallback>
                            {cls.type === "teaching" ? "JS" : "MS"}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-start justify-between">
                            <div>
                              <h4 className="font-medium">{cls.title}</h4>
                              <p className="text-sm text-gray-600">
                                {cls.type === "teaching" 
                                  ? `Aluno: ${cls.student}` 
                                  : `Professor: ${cls.teacher}`
                                }
                              </p>
                            </div>
                            <Badge variant={cls.type === "teaching" ? "default" : "secondary"}>
                              {cls.type === "teaching" ? "Ensinando" : "Aprendendo"}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                            <span className="flex items-center gap-1">
                              <Calendar className="size-4" />
                              {cls.date}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="size-4" />
                              {cls.time}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </TabsContent>

                <TabsContent value="recommended" className="space-y-4">
                  <div className="text-center py-8 text-gray-500">
                    <Star className="size-12 mx-auto mb-3 opacity-50" />
                    <p>Complete seu perfil para receber recomendações personalizadas</p>
                  </div>
                </TabsContent>
              </Tabs>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Activity Feed */}
            <Card className="p-6">
              <h3 className="text-lg mb-4 flex items-center gap-2">
                <TrendingUp className="size-5" />
                Atividade Recente
              </h3>
              <div className="space-y-4">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex gap-3">
                    <div className="text-2xl">{activity.icon}</div>
                    <div className="flex-1">
                      <p className="text-sm">{activity.text}</p>
                      <p className="text-xs text-gray-500">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Community */}
            <Card className="p-6 bg-gradient-to-br from-blue-50 to-purple-50">
              <h3 className="text-lg mb-3">💡 Dica do Dia</h3>
              <p className="text-sm text-gray-700 mb-4">
                Completar seu perfil aumenta em 5x as chances de receber convites para ensinar e aprender!
              </p>
              <Button variant="outline" size="sm" className="w-full">
                Completar Perfil
              </Button>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}