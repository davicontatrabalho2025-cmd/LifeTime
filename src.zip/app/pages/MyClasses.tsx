import { AppLayout } from "../components/layout/AppLayout";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Avatar, AvatarFallback } from "../components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import {
  Calendar,
  Clock,
  Plus,
  Video,
  MessageCircle,
  Star,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";

export function MyClasses() {
  const upcomingClasses = [
    {
      id: 1,
      title: "Design Thinking Básico",
      type: "teaching" as const,
      student: "João Santos",
      date: "22 Mar 2026",
      time: "10:00 - 11:30",
      location: "Online",
      credits: 1,
      status: "confirmed",
    },
  ];

  const pastClasses = [
    {
      id: 1,
      title: "Introdução ao Python",
      type: "learning" as const,
      teacher: "Maria Silva",
      date: "18 Mar 2026",
      time: "14:00 - 16:00",
      location: "Online",
      credits: 2,
      rating: 5,
    },
  ];

  const handleCancelClass = (classId: number) => {
    toast.success("Aula cancelada. Créditos reembolsados.");
  };

  return (
    <AppLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl mb-2">Minhas Aulas</h1>
            <p className="text-gray-600">
              Gerencie suas aulas agendadas e histórico
            </p>
          </div>
          <Button size="lg">
            <Plus className="mr-2 size-5" />
            Criar Nova Aula
          </Button>
        </div>

        <Tabs defaultValue="upcoming">
          <TabsList>
            <TabsTrigger value="upcoming">Próximas Aulas</TabsTrigger>
            <TabsTrigger value="past">Histórico</TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming" className="mt-6">
            {upcomingClasses.length > 0 ? (
              <div className="space-y-4">
                {upcomingClasses.map((cls) => (
                  <Card key={cls.id} className="p-6">
                    <div className="flex items-start gap-6">
                      <Avatar className="size-16">
                        <AvatarFallback>
                          {cls.type === "teaching" ? "JS" : "MS"}
                        </AvatarFallback>
                      </Avatar>

                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="text-2xl">{cls.title}</h3>
                              <Badge
                                variant={
                                  cls.type === "teaching" ? "default" : "secondary"
                                }
                              >
                                {cls.type === "teaching" ? "Ensinando" : "Aprendendo"}
                              </Badge>
                            </div>
                            <p className="text-gray-600">
                              {cls.type === "teaching"
                                ? `Aluno: ${cls.student}`
                                : `Professor: ${cls.teacher || "N/A"}`}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-3xl text-blue-600 mb-1">
                              {cls.credits}
                            </p>
                            <p className="text-sm text-gray-600">créditos</p>
                          </div>
                        </div>

                        <div className="grid md:grid-cols-3 gap-4 mb-4">
                          <div className="flex items-center gap-2 text-gray-600">
                            <Calendar className="size-5" />
                            <span>{cls.date}</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-600">
                            <Clock className="size-5" />
                            <span>{cls.time}</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-600">
                            <Video className="size-5" />
                            <span>{cls.location}</span>
                          </div>
                        </div>

                        <div className="flex gap-3">
                          <Button>
                            <Video className="mr-2 size-4" />
                            Entrar na Sala
                          </Button>
                          <Button variant="outline">
                            <MessageCircle className="mr-2 size-4" />
                            Mensagem
                          </Button>
                          <Button
                            variant="outline"
                            onClick={() => handleCancelClass(cls.id)}
                          >
                            <XCircle className="mr-2 size-4" />
                            Cancelar
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center">
                <Calendar className="size-16 mx-auto mb-4 text-gray-400" />
                <h3 className="text-xl mb-2">Nenhuma aula agendada</h3>
                <p className="text-gray-600 mb-6">
                  Que tal criar uma aula ou buscar no marketplace?
                </p>
                <div className="flex gap-3 justify-center">
                  <Button>Criar Aula</Button>
                  <Button variant="outline">Explorar Marketplace</Button>
                </div>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="past" className="mt-6">
            {pastClasses.length > 0 ? (
              <div className="space-y-4">
                {pastClasses.map((cls) => (
                  <Card key={cls.id} className="p-6 bg-gray-50">
                    <div className="flex items-start gap-6">
                      <Avatar className="size-16">
                        <AvatarFallback>MS</AvatarFallback>
                      </Avatar>

                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="text-2xl">{cls.title}</h3>
                              <Badge variant="outline">Concluída</Badge>
                            </div>
                            <p className="text-gray-600">
                              Professor: {cls.teacher}
                            </p>
                          </div>
                          <div className="text-right">
                            <div className="flex items-center gap-1 mb-1">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`size-5 ${
                                    i < (cls.rating || 0)
                                      ? "fill-yellow-400 text-yellow-400"
                                      : "text-gray-300"
                                  }`}
                                />
                              ))}
                            </div>
                            <p className="text-sm text-gray-600">
                              Sua avaliação
                            </p>
                          </div>
                        </div>

                        <div className="grid md:grid-cols-3 gap-4 mb-4">
                          <div className="flex items-center gap-2 text-gray-600">
                            <Calendar className="size-5" />
                            <span>{cls.date}</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-600">
                            <Clock className="size-5" />
                            <span>{cls.time}</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-600">
                            <span className="text-blue-600 font-medium">
                              -{cls.credits} créditos
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center">
                <p className="text-gray-600">Nenhuma aula no histórico ainda</p>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
