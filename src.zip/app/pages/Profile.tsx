import { useState } from "react";
import { AppLayout } from "../components/layout/AppLayout";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Textarea } from "../components/ui/textarea";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Label } from "../components/ui/label";
import { Avatar, AvatarFallback } from "../components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import {
  User,
  Mail,
  Building2,
  Edit,
  Star,
  Award,
  Clock,
  TrendingUp,
  Save,
} from "lucide-react";
import { toast } from "sonner";

export function Profile() {
  const [isEditing, setIsEditing] = useState(false);
  const [profile, setProfile] = useState({
    name: "Usuário LifeTime",
    email: "usuario@lifetime.com",
    institution: "Autônomo",
    bio: "",
    skills: ["JavaScript", "Python"],
    interests: ["Design", "Marketing"],
  });

  const stats = {
    classesTeaching: 0,
    classesLearning: 0,
    totalCreditsEarned: 0,
    totalCreditsSpent: 0,
    rating: 0,
    reviews: 0,
  };

  const handleSave = () => {
    toast.success("Perfil atualizado com sucesso!");
    setIsEditing(false);
  };

  return (
    <AppLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl mb-2">Meu Perfil</h1>
          <p className="text-gray-600">
            Gerencie suas informações e configurações
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Sidebar - Profile Card */}
          <div className="lg:col-span-1">
            <Card className="p-6">
              <div className="text-center mb-6">
                <Avatar className="size-32 mx-auto mb-4">
                  <AvatarFallback className="text-3xl">
                    {profile.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <h2 className="text-2xl mb-1">{profile.name}</h2>
                <p className="text-gray-600">{profile.email}</p>
                <Badge variant="secondary" className="mt-2">
                  <Building2 className="mr-1 size-3" />
                  {profile.institution}
                </Badge>
              </div>

              <div className="space-y-4 border-t pt-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Avaliação</span>
                  <div className="flex items-center gap-1">
                    <Star className="size-4 fill-yellow-400 text-yellow-400" />
                    <span className="font-medium">
                      {stats.rating > 0 ? stats.rating.toFixed(1) : "N/A"}
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Aulas Ensinadas</span>
                  <span className="font-medium">{stats.classesTeaching}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Aulas Aprendidas</span>
                  <span className="font-medium">{stats.classesLearning}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Créditos Ganhos</span>
                  <span className="font-medium text-green-600">
                    +{stats.totalCreditsEarned}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Créditos Gastos</span>
                  <span className="font-medium text-orange-600">
                    -{stats.totalCreditsSpent}
                  </span>
                </div>
              </div>

              <Button className="w-full mt-6" variant="outline">
                <Award className="mr-2 size-4" />
                Ver Certificados
              </Button>
            </Card>

            {/* Achievements */}
            <Card className="p-6 mt-6">
              <h3 className="mb-4 flex items-center gap-2">
                <TrendingUp className="size-5 text-blue-600" />
                Conquistas
              </h3>
              <div className="space-y-3">
                <div className="p-3 bg-green-50 rounded-lg">
                  <p className="text-sm font-medium mb-1">🎉 Bem-vindo!</p>
                  <p className="text-xs text-gray-600">Cadastro concluído</p>
                </div>
                <div className="p-3 bg-gray-100 rounded-lg opacity-50">
                  <p className="text-sm font-medium mb-1">📚 Primeira Aula</p>
                  <p className="text-xs text-gray-600">
                    Complete sua primeira aula
                  </p>
                </div>
                <div className="p-3 bg-gray-100 rounded-lg opacity-50">
                  <p className="text-sm font-medium mb-1">⭐ Professor Estrela</p>
                  <p className="text-xs text-gray-600">
                    Receba sua primeira avaliação 5 estrelas
                  </p>
                </div>
              </div>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="info">
              <TabsList>
                <TabsTrigger value="info">
                  <User className="mr-2 size-4" />
                  Informações
                </TabsTrigger>
                <TabsTrigger value="skills">
                  <Award className="mr-2 size-4" />
                  Habilidades
                </TabsTrigger>
                <TabsTrigger value="reviews">
                  <Star className="mr-2 size-4" />
                  Avaliações
                </TabsTrigger>
              </TabsList>

              <TabsContent value="info" className="mt-6">
                <Card className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-2xl">Informações Pessoais</h3>
                    {!isEditing ? (
                      <Button
                        variant="outline"
                        onClick={() => setIsEditing(true)}
                      >
                        <Edit className="mr-2 size-4" />
                        Editar
                      </Button>
                    ) : (
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          onClick={() => setIsEditing(false)}
                        >
                          Cancelar
                        </Button>
                        <Button onClick={handleSave}>
                          <Save className="mr-2 size-4" />
                          Salvar
                        </Button>
                      </div>
                    )}
                  </div>

                  <div className="space-y-6">
                    <div>
                      <Label htmlFor="name">Nome Completo</Label>
                      <Input
                        id="name"
                        value={profile.name}
                        onChange={(e) =>
                          setProfile({ ...profile, name: e.target.value })
                        }
                        disabled={!isEditing}
                      />
                    </div>

                    <div>
                      <Label htmlFor="email">E-mail</Label>
                      <div className="flex gap-2">
                        <Input
                          id="email"
                          value={profile.email}
                          disabled
                          className="flex-1"
                        />
                        <Badge variant="secondary" className="shrink-0">
                          Verificado
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-500 mt-1">
                        E-mail não pode ser alterado
                      </p>
                    </div>

                    <div>
                      <Label htmlFor="institution">
                        Instituição / Organização
                      </Label>
                      <Input
                        id="institution"
                        value={profile.institution}
                        onChange={(e) =>
                          setProfile({
                            ...profile,
                            institution: e.target.value,
                          })
                        }
                        disabled={!isEditing}
                      />
                    </div>

                    <div>
                      <Label htmlFor="bio">Sobre você</Label>
                      <Textarea
                        id="bio"
                        value={profile.bio}
                        onChange={(e) =>
                          setProfile({ ...profile, bio: e.target.value })
                        }
                        disabled={!isEditing}
                        rows={4}
                        placeholder="Conte um pouco sobre você, suas experiências e objetivos..."
                      />
                    </div>
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="skills" className="mt-6">
                <Card className="p-6">
                  <h3 className="text-2xl mb-6">Habilidades e Interesses</h3>

                  <div className="space-y-6">
                    <div>
                      <Label className="mb-3 block">
                        Habilidades que você ensina
                      </Label>
                      <div className="flex flex-wrap gap-2">
                        {profile.skills.length > 0 ? (
                          profile.skills.map((skill) => (
                            <Badge key={skill} variant="default">
                              {skill}
                            </Badge>
                          ))
                        ) : (
                          <p className="text-sm text-gray-500">
                            Nenhuma habilidade adicionada
                          </p>
                        )}
                      </div>
                      {isEditing && (
                        <Button variant="outline" size="sm" className="mt-3">
                          Adicionar Habilidade
                        </Button>
                      )}
                    </div>

                    <div>
                      <Label className="mb-3 block">
                        O que você quer aprender
                      </Label>
                      <div className="flex flex-wrap gap-2">
                        {profile.interests.length > 0 ? (
                          profile.interests.map((interest) => (
                            <Badge key={interest} variant="outline">
                              {interest}
                            </Badge>
                          ))
                        ) : (
                          <p className="text-sm text-gray-500">
                            Nenhum interesse adicionado
                          </p>
                        )}
                      </div>
                      {isEditing && (
                        <Button variant="outline" size="sm" className="mt-3">
                          Adicionar Interesse
                        </Button>
                      )}
                    </div>
                  </div>

                  {!isEditing && (
                    <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                      <p className="text-sm text-gray-700">
                        💡 Adicione mais habilidades e interesses para receber
                        recomendações personalizadas de aulas!
                      </p>
                    </div>
                  )}
                </Card>
              </TabsContent>

              <TabsContent value="reviews" className="mt-6">
                <Card className="p-6">
                  <h3 className="text-2xl mb-6">Avaliações Recebidas</h3>

                  {stats.reviews === 0 ? (
                    <div className="text-center py-12">
                      <Star className="size-16 mx-auto mb-4 text-gray-300" />
                      <h4 className="text-xl mb-2">Nenhuma avaliação ainda</h4>
                      <p className="text-gray-600">
                        Complete sua primeira aula para receber avaliações
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* Placeholder para futuras avaliações */}
                    </div>
                  )}
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
