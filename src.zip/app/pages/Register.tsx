import { useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Progress } from "../components/ui/progress";
import { ArrowLeft, CheckCircle2 } from "lucide-react";
import { Step1AuthMethod } from "../components/register/Step1AuthMethod";
import { Step2BasicInfo } from "../components/register/Step2BasicInfo";
import { Step3AdditionalInfo } from "../components/register/Step3AdditionalInfo";
import { Step4Validation } from "../components/register/Step4Validation";
import { Step5EmailSent } from "../components/register/Step5EmailSent";
import { Step6ProfileSetup } from "../components/register/Step6ProfileSetup";
import { Step7Review } from "../components/register/Step7Review";

export type RegistrationData = {
  authMethod?: "email" | "google" | "microsoft";
  name?: string;
  email?: string;
  password?: string;
  institution?: string;
  userType?: "teacher" | "learner" | "both";
  skills?: string[];
  interests?: string[];
  bio?: string;
  profileComplete?: boolean;
};

export function Register() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [registrationData, setRegistrationData] = useState<RegistrationData>({});

  const totalSteps = 7;
  const progress = (currentStep / totalSteps) * 100;

  const updateData = (data: Partial<RegistrationData>) => {
    setRegistrationData(prev => ({ ...prev, ...data }));
  };

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(prev => prev + 1);
    } else {
      // Completar registro
      navigate("/verify-email", { state: { email: registrationData.email } });
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const stepTitles = [
    "Método de Cadastro",
    "Dados Básicos",
    "Informações Adicionais",
    "Validação Automática",
    "Verificação de E-mail",
    "Configure seu Perfil",
    "Revisão Final"
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="max-w-4xl mx-auto mb-8">
          <Button 
            variant="ghost" 
            onClick={() => currentStep === 1 ? navigate("/") : prevStep()}
          >
            <ArrowLeft className="mr-2 size-4" />
            {currentStep === 1 ? "Voltar ao início" : "Etapa anterior"}
          </Button>
        </div>

        {/* Progress */}
        <div className="max-w-4xl mx-auto mb-8">
          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-600">
                Etapa {currentStep} de {totalSteps}
              </span>
              <span className="text-sm text-gray-600">
                {Math.round(progress)}% concluído
              </span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
          <h2 className="text-3xl text-center">{stepTitles[currentStep - 1]}</h2>
        </div>

        {/* Step Content */}
        <div className="max-w-4xl mx-auto">
          <Card className="p-8">
            {currentStep === 1 && (
              <Step1AuthMethod 
                onNext={nextStep}
                onSelectMethod={(method) => updateData({ authMethod: method })}
                selectedMethod={registrationData.authMethod}
              />
            )}
            {currentStep === 2 && (
              <Step2BasicInfo 
                onNext={nextStep}
                onUpdate={updateData}
                data={registrationData}
              />
            )}
            {currentStep === 3 && (
              <Step3AdditionalInfo 
                onNext={nextStep}
                onUpdate={updateData}
                data={registrationData}
              />
            )}
            {currentStep === 4 && (
              <Step4Validation 
                onNext={nextStep}
                data={registrationData}
              />
            )}
            {currentStep === 5 && (
              <Step5EmailSent 
                onNext={nextStep}
                email={registrationData.email}
              />
            )}
            {currentStep === 6 && (
              <Step6ProfileSetup 
                onNext={nextStep}
                onUpdate={updateData}
                data={registrationData}
              />
            )}
            {currentStep === 7 && (
              <Step7Review 
                onComplete={nextStep}
                data={registrationData}
              />
            )}
          </Card>

          {/* Step Indicators */}
          <div className="flex justify-center gap-2 mt-8">
            {Array.from({ length: totalSteps }).map((_, index) => (
              <div
                key={index}
                className={`h-2 rounded-full transition-all ${
                  index + 1 === currentStep
                    ? "w-8 bg-blue-600"
                    : index + 1 < currentStep
                    ? "w-2 bg-green-500"
                    : "w-2 bg-gray-300"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
