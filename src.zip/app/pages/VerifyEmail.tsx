import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { CheckCircle2, Loader2, Mail } from "lucide-react";

export function VerifyEmail() {
  const navigate = useNavigate();
  const location = useLocation();
  const [isVerifying, setIsVerifying] = useState(true);
  const [verified, setVerified] = useState(false);

  const email = (location.state as any)?.email || "seu@email.com";

  useEffect(() => {
    // Simular verificação de e-mail
    const timer = setTimeout(() => {
      setIsVerifying(false);
      setVerified(true);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  const handleContinue = () => {
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4">
      <Card className="max-w-md w-full p-8 text-center">
        {isVerifying ? (
          <>
            <div className="bg-blue-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Loader2 className="size-10 text-blue-600 animate-spin" />
            </div>
            <h2 className="text-2xl mb-2">Verificando e-mail...</h2>
            <p className="text-gray-600">
              Aguarde enquanto confirmamos seu endereço de e-mail
            </p>
          </>
        ) : verified ? (
          <>
            <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 animate-bounce">
              <CheckCircle2 className="size-10 text-green-600" />
            </div>
            <h2 className="text-3xl mb-2">E-mail Verificado!</h2>
            <p className="text-gray-600 mb-2">
              Bem-vindo(a) ao <strong>LifeTime</strong>!
            </p>
            <p className="text-gray-600 mb-8">
              Seu cadastro foi concluído com sucesso. Você já pode começar a ensinar e aprender.
            </p>

            <div className="bg-blue-50 p-6 rounded-lg mb-6">
              <Mail className="size-8 text-blue-600 mx-auto mb-3" />
              <p className="text-sm text-gray-700">
                Enviamos um e-mail de boas-vindas para <strong>{email}</strong> com 
                dicas para começar na plataforma.
              </p>
            </div>

            <Button onClick={handleContinue} className="w-full" size="lg">
              Ir para o Dashboard
            </Button>
          </>
        ) : (
          <>
            <div className="bg-red-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Mail className="size-10 text-red-600" />
            </div>
            <h2 className="text-2xl mb-2">Erro na Verificação</h2>
            <p className="text-gray-600 mb-6">
              Não foi possível verificar seu e-mail. Por favor, tente novamente.
            </p>
            <Button onClick={() => navigate("/register")} className="w-full">
              Voltar ao Cadastro
            </Button>
          </>
        )}
      </Card>
    </div>
  );
}
